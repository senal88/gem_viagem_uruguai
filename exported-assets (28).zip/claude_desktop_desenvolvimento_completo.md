# 💻 GUIA COMPLETO: CLAUDE DESKTOP PARA DESENVOLVIMENTO GEM
## Desenvolva Seu Concierge IA com Claude Desktop + MCP
### Integração Total com GitHub, Python e API

---

## 📋 ÍNDICE

1. [Visão Geral](#1-visão-geral)
2. [Instalação Claude Desktop](#2-instalação-claude-desktop)
3. [Setup MCP (Model Context Protocol)](#3-setup-mcp)
4. [Integração GitHub MCP](#4-integração-github-mcp)
5. [Workflow de Desenvolvimento](#5-workflow-de-desenvolvimento)
6. [Exemplos Práticos](#6-exemplos-práticos)
7. [Troubleshooting](#7-troubleshooting)

---

## 1. VISÃO GERAL

### Por Que Claude Desktop?

Claude Desktop é um **IDE com IA integrada** que permite:

```
┌─────────────────────────────────────────────────┐
│          CLAUDE DESKTOP (Local)                  │
│                                                  │
│  ✅ Acesso direto a arquivos do seu PC         │
│  ✅ Integração nativa com GitHub (MCP)         │
│  ✅ Terminal integrado (executar Python)       │
│  ✅ Leitura/escrita de código em tempo real    │
│  ✅ Contexto gigante (200k tokens)             │
│  ✅ Sem limites de rate (local)                │
│  ✅ Privacidade total (dados no seu PC)        │
│                                                  │
└─────────────────────────────────────────────────┘
        ↓ MCP (Model Context Protocol)
┌─────────────────────────────────────────────────┐
│     SEUS DADOS LOCAIS (GitHub, Arquivos)        │
│                                                  │
│  • Repositório GitHub                          │
│  • Código Python (src/)                        │
│  • Documentação Markdown                       │
│  • Dados JSON (itinerário)                     │
│  • Testes e logs                               │
│                                                  │
└─────────────────────────────────────────────────┘
```

### Fluxo de Desenvolvimento

```
1. CONVERSA COM CLAUDE
   "Crie uma função para carregar JSON do GitHub"
        ↓
2. CLAUDE ACESSA SEUS ARQUIVOS (MCP)
   Lê: src/github_client.py, dados/, docs/
        ↓
3. CLAUDE PROPÕE CÓDIGO
   "Aqui está a implementação..."
        ↓
4. VOCÊ APROVA E EXECUTA
   Claude escreve no arquivo + você testa no terminal
        ↓
5. ITERAÇÃO
   "Agora adicione tratamento de erro"
   → Claude modifica o código existente
        ↓
6. COMMIT AUTOMÁTICO
   Claude cria pull request para seu GitHub
```

---

## 2. INSTALAÇÃO CLAUDE DESKTOP

### 2.1 Download e Setup

```bash
# 1. Baixar Claude Desktop
# Acesse: https://claude.ai/download
# Ou (Mac): https://www.anthropic.com/download

# 2. Instalar
# macOS: Drag para Applications
# Windows: Executar instalador
# Linux: Ver instruções em https://support.claude.com

# 3. Abrir Claude Desktop
# ✅ Primeira vez: fazer login com conta Anthropic
# ✅ Verificar: Settings → ativar "Claude for Work" (opcional, pago)
```

### 2.2 Primeira Execução

```
1. Abrir Claude Desktop
2. Clique em "+" (novo chat)
3. Começar a conversar
4. Você verá: botão para adicionar contexto (arquivos, GitHub)
```

---

## 3. SETUP MCP (Model Context Protocol)

### 3.1 Entender MCP

```
MCP = "USB-C para IA"

Sem MCP:
  Claude Desktop ❌ Acesso a arquivos
  Claude Desktop ❌ Acesso a GitHub
  Claude Desktop ❌ Pode executar código

Com MCP:
  Claude Desktop ✅ Lê/escreve arquivos
  Claude Desktop ✅ Integra GitHub
  Claude Desktop ✅ Executa ferramentas
  Claude Desktop ✅ Acesso terminal
```

### 3.2 Instalar Dependências MCP

```bash
# Pré-requisitos
# 1. Node.js (para alguns MCPs)
# 2. Python 3.10+ (já tem)
# 3. Git (já tem)

# Verificar
node --version      # v18+
python --version    # 3.10+
git --version      # qualquer versão

# Instalar Node.js (se não tiver)
# macOS: brew install node
# Windows: https://nodejs.org (download LTS)
# Linux: sudo apt-get install nodejs
```

### 3.3 Configurar MCP no Claude Desktop

Claude Desktop usa arquivo de configuração `claude_desktop_config.json`

#### Local do arquivo:

```
macOS: ~/Library/Application Support/Claude/claude_desktop_config.json
Windows: %APPDATA%\Claude\claude_desktop_config.json
Linux: ~/.config/Claude/claude_desktop_config.json
```

#### Criar arquivo de configuração:

```json
{
  "mcpServers": {
    "filesystem": {
      "command": "python",
      "args": ["-m", "mcp.server.filesystem", "--directory", "/Users/seu_user/gem_viagem_uruguai"]
    },
    "github": {
      "command": "node",
      "args": ["/path/to/git-mcp-server/dist/index.js"],
      "env": {
        "GITHUB_PERSONAL_ACCESS_TOKEN": "seu_token_aqui"
      }
    }
  }
}
```

### 3.4 Instalar MCP Servers Pré-Construídos

```bash
# Opção A: Usar MCP Servers Oficiais (RECOMENDADO)

# 1. Filesystem MCP (acessar arquivos locais)
pip install mcp[server]

# 2. Git/GitHub MCP
npm install -g @anthropic-sdks/github-mcp-server

# 3. Verificar instalação
python -m mcp.server.filesystem --help
```

---

## 4. INTEGRAÇÃO GITHUB MCP

### 4.1 Obter Token GitHub

```bash
# 1. Ir para: https://github.com/settings/tokens
# 2. "Generate new token" → "Generate new token (classic)"
# 3. Nome: "Claude Desktop MCP"
# 4. Scopes:
#    ✅ repo (acesso completo ao repositório)
#    ✅ read:org (ler organização)
#    ✅ admin:repo_hook (webhooks)
# 5. Copiar token (será usado uma vez)
```

### 4.2 Configurar GitHub MCP

```json
// claude_desktop_config.json - Seção GitHub

{
  "mcpServers": {
    "github": {
      "command": "node",
      "args": ["-e", "require('@anthropic-sdks/github-mcp-server').default()"],
      "env": {
        "GITHUB_PERSONAL_ACCESS_TOKEN": "ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
      }
    }
  }
}
```

### 4.3 Testar Integração GitHub

```
No Claude Desktop:

1. Novo chat
2. Clique em "+" (adicionar contexto)
3. Selecione "Add GitHub Repository"
4. Procure: senal88/gem_viagem_uruguai
5. Selecione arquivos que quer indexar
6. Pergunte: "Qual é o status do repositório?"

✅ Se funcionar: Claude mostrará informações do repo
```

---

## 5. WORKFLOW DE DESENVOLVIMENTO

### 5.1 Configuração Local Inicial

```bash
# 1. Clone seu repositório
git clone https://github.com/senal88/gem_viagem_uruguai.git
cd gem_viagem_uruguai

# 2. Crie estrutura (se não existir)
mkdir -p src data/conhecimento tests
touch .env .gitignore requirements.txt

# 3. Abra Claude Desktop
# Adicione seu projeto via MCP (Filesystem)
```

### 5.2 Fluxo de Desenvolvimento (Passo-a-Passo)

#### Fase 1: Planejamento (Chat 1)

```
Você para Claude:
"Preciso criar um concierge IA para viagem ao Uruguai.
Tenho estes arquivos no GitHub:
- 01_protocolo_busca_web.md
- 02_gatilhos_validacao.md
- dados_aline_luiz.json

Qual é o plano de desenvolvimento?"

Claude responde com:
- Arquitetura
- Dependências
- Sequência de implementação
```

#### Fase 2: Setup Inicial (Chat 2)

```
Você para Claude:
"Crie os arquivos iniciais:
1. requirements.txt com dependências
2. .env.example
3. src/config.py com configurações"

Claude:
- Escreve os arquivos
- Você: "Claude, escreva isso no meu projeto"
- Claude escreve nos arquivos (MCP)
- Você executa: pip install -r requirements.txt
```

#### Fase 3: Cliente GitHub (Chat 3)

```
Você para Claude:
"Crie src/github_client.py que:
1. Clona repositório
2. Lê arquivos Markdown
3. Parseia JSON do itinerário"

Claude:
- Lê seus arquivos existentes (via MCP)
- Propõe implementação contextualizada
- Você aprova: "Perfeito, escreva no projeto"
- Claude escreve em src/github_client.py
```

#### Fase 4: Cliente Claude/Gemini (Chat 4)

```
Você para Claude:
"Crie src/claude_client.py que:
1. Integra com Claude API
2. Usa File Search (RAG)
3. Gera respostas contextualizadas"

Claude:
- Propõe código
- Você testa: python -c "from src.claude_client import ClaudioClient"
- Itera conforme necessário
```

#### Fase 5: Integração Completa (Chat 5)

```
Você para Claude:
"Crie src/main.py que orquestra tudo:
1. Carrega GitHub
2. Inicializa Claude
3. Cria interface interativa"

Claude:
- Escreve main.py
- Você testa: python src/main.py
- Testa com pergunta real
```

#### Fase 6: Refinamento (Chat 6+)

```
Você: "A resposta está muito longa. Resumir."
Claude: Modifica, você testa
Você: "Adicionar busca web."
Claude: Integra Perplexity API
Você: "Funciona! Melhorar error handling."
Claude: Adiciona try/except robusto
```

---

## 6. EXEMPLOS PRÁTICOS

### 6.1 Exemplo Real: Criar GitHub Client

**Seu input para Claude:**

```
Oi Claude! Preciso de um arquivo src/github_client.py que:

1. Conecte ao GitHub usando PyGithub
2. Clone meu repositório: senal88/gem_viagem_uruguai
3. Leia todos os arquivos Markdown (01_, 02_, 03_, 04_)
4. Parse o JSON em data/dados_aline_luiz.json
5. Retorne um dicionário com todo conhecimento

Aqui estão meus arquivos existentes para contexto:
- requirements.txt (versões)
- config.py (configurações)

Crie um arquivo bem estruturado com docstrings em português.
```

**Claude Desktop (com MCP):**

```
✅ Clique em "+" → Add Filesystem
✅ Selecione ~/gem_viagem_uruguai
✅ Claude agora pode ver seus arquivos

Proposta:

```python
# src/github_client.py

import os
from github import Github
import json

class GitHubClient:
    def __init__(self, repo_owner="senal88", repo_name="gem_viagem_uruguai"):
        """
        Inicializa cliente GitHub
        
        Args:
            repo_owner: Proprietário do repositório
            repo_name: Nome do repositório
        """
        self.github = Github(os.getenv("GITHUB_TOKEN"))
        self.repo = self.github.get_user(repo_owner).get_repo(repo_name)
    
    def get_all_markdown_files(self):
        """Retorna todos os arquivos .md (protocolo, gatilhos, etc)"""
        markdown_files = {}
        files_to_fetch = [
            "01_protocolo_busca_web.md",
            "02_gatilhos_validacao.md",
            "03_categorias_perguntas.md",
            "04_fontes_conhecimento_validadas.md"
        ]
        
        for filename in files_to_fetch:
            try:
                content = self.repo.get_contents(filename)
                markdown_files[filename] = content.decoded_content.decode('utf-8')
                print(f"✅ Carregado: {filename}")
            except Exception as e:
                print(f"❌ Erro: {e}")
        
        return markdown_files
    
    def get_itinerary_json(self):
        """Carrega itinerário JSON"""
        try:
            content = self.repo.get_contents("data/dados_aline_luiz.json")
            return json.loads(content.decoded_content.decode('utf-8'))
        except Exception as e:
            print(f"❌ Erro ao carregar JSON: {e}")
            return None
```

Você responde:
"Perfeito! Escreva no projeto"

Claude:
- Escreve automaticamente em src/github_client.py
- Você executa teste:
```bash
python -c "from src.github_client import GitHubClient; gc = GitHubClient()"
```
✅ Sucesso!
```

### 6.2 Exemplo Real: Criar Concierge

**Seu input:**

```
Claude, agora preciso de src/concierge.py que:

1. Use GitHubClient para carregar dados
2. Inicialize Claude API
3. Use File Search para RAG
4. Processe perguntas do usuário
5. Retorne respostas contextualizadas

Faça com error handling robusto e logging.
```

**Claude Desktop:**

```
Claude lê seus arquivos (MCP):
- github_client.py ✅
- config.py ✅
- requirements.txt ✅

Propõe:

```python
# src/concierge.py

import anthropic
from github_client import GitHubClient
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ConciergeAI:
    def __init__(self):
        """Inicializa concierge IA"""
        try:
            self.knowledge_loader = GitHubClient()
            self.client = anthropic.Anthropic()
            logger.info("✅ Concierge AI inicializado")
        except Exception as e:
            logger.error(f"❌ Erro ao inicializar: {e}")
            raise
    
    def process_question(self, question):
        """Processa pergunta do usuário"""
        try:
            # Carregar contexto
            markdown_files = self.knowledge_loader.get_all_markdown_files()
            itinerary = self.knowledge_loader.get_itinerary_json()
            
            # Criar prompt
            system_prompt = f"""
            Você é concierge para Aline e Luiz na viagem ao Uruguai.
            
            Itinerário:
            {itinerary}
            
            Conhecimento:
            {str(markdown_files)[:500]}...
            """
            
            # Gerar resposta
            response = self.client.messages.create(
                model="claude-3-5-sonnet-20241022",
                max_tokens=1024,
                system=system_prompt,
                messages=[{"role": "user", "content": question}]
            )
            
            return response.content[0].text
        
        except Exception as e:
            logger.error(f"❌ Erro ao processar pergunta: {e}")
            return f"Desculpe, ocorreu um erro: {str(e)}"
```

Você testa:
"Escreva no projeto e teste com a pergunta: 'Qual a previsão para sábado?'"
```

---

## 7. TROUBLESHOOTING

### Erro: MCP não carrega

```
Erro: "MCP server not found"

Solução:
1. Verificar claude_desktop_config.json
2. Reiniciar Claude Desktop
3. Verificar caminhos absolutos (não ~)
4. Executar no terminal: python -m mcp.server.filesystem --help
```

### Erro: GitHub Token inválido

```
Erro: "Bad credentials"

Solução:
1. Verificar token em: https://github.com/settings/tokens
2. Confirmar que não expirou
3. Confirmar scopes (repo, read:org)
4. Gerar novo token se necessário
5. Atualizar .env e claude_desktop_config.json
```

### Claude Desktop muito lento

```
Causa: Muitos arquivos indexados

Solução:
1. Adicionar .gitignore no MCP
2. Reduzir arquivos selecionados
3. Usar "Configurar arquivos" para escolher apenas necessários
4. Reiniciar Claude Desktop
```

### Código não é escrito nos arquivos

```
Causa: Permissões ou MCP não ativado

Solução:
1. Verificar permissões: chmod +w src/*.py
2. Verificar que MCP Filesystem está ativado
3. Clicar em "Write file" explicitamente
4. Confirmar caminho correto
```

---

## 📊 WORKFLOW RECOMENDADO

```
DIA 1 - SETUP (2-3 horas)
├─ Instalar Claude Desktop
├─ Configurar MCP (Filesystem + GitHub)
├─ Testar integração
└─ Criar estrutura inicial

DIA 2 - DESENVOLVIMENTO (4-6 horas)
├─ Chat 1: Planejamento
├─ Chat 2: Setup
├─ Chat 3-5: Implementação (1 componente/chat)
├─ Testes incrementais
└─ Git commit

DIA 3 - REFINAMENTO (2-4 horas)
├─ Chat 6+: Melhorias iterativas
├─ Testes de integração
├─ Deploy (local ou Cloud)
└─ Documentação final
```

---

## 🎯 CHECKLIST IMPLEMENTAÇÃO

### Preparação
- [ ] Claude Desktop instalado
- [ ] Conta Anthropic criada
- [ ] Node.js instalado
- [ ] GitHub token gerado

### Configuração MCP
- [ ] Filesystem MCP configurado
- [ ] GitHub MCP configurado
- [ ] claude_desktop_config.json atualizado
- [ ] Claude Desktop reiniciado

### Desenvolvimento
- [ ] Chat 1: Planejamento completo
- [ ] Chat 2: Setup com requirements.txt
- [ ] Chat 3: GitHubClient funcionando
- [ ] Chat 4: ClaudioClient funcionando
- [ ] Chat 5: Main.py integrado
- [ ] Chat 6+: Testes e refinamento

### Deployment
- [ ] Testes locais passando
- [ ] GitHub commit feito
- [ ] Deployment em nuvem (opcional)
- [ ] Documentação pronta

---

## 💡 DICAS OURO

1. **Use "Add from GitHub" para sincronizar**: Claude Desktop → "+" → "Add GitHub Repository"
2. **Sempre comece com planejamento**: Primeira conversa deve ser arquitetura
3. **Itere pequeno**: Um componente por chat, teste após cada
4. **Use terminal integrado**: `Ctrl+`` dentro do Claude
5. **Mantenha contexto**: Use "Sync" para manter arquivos atualizados
6. **Git frequente**: Commit após cada milestone
7. **Documente enquanto cria**: Peça a Claude para adicionar docstrings

---

## 📚 RECURSOS ADICIONAIS

- [Claude Desktop Documentation](https://support.claude.com)
- [MCP Specification](https://modelcontextprotocol.io)
- [GitHub MCP Server](https://github.com/anthropics/github-mcp-server)
- [Anthropic API Documentation](https://docs.anthropic.com)

---

**Versão:** 1.0 | **Status:** Pronto para Usar  
**Última atualização:** 16 de Novembro de 2025